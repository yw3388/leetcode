package leetcode;

import java.util.List;

/*
 * 559 max depth of a nary tree
 * 
 */

//Definition for a Node.
class Node {
 public int val;
 public java.util.List<Node> children;

 public Node() {}

 public Node(int _val) {
     val = _val;
 }

 public Node(int _val, List<Node> _children) {
     val = _val;
     children = _children;
 }
};


public class maxdepth {
	public int max = 0;
    public int maxDepth(Node root) {
       
        if (root == null) return 0;
        //pass root to calculate method
        get(root, 1);
        return max;
    }
    public void get(Node node, int depth){
        if(node == null) return;
        for (Node c: node.children){
            get(c, depth + 1);
        }
        //recursively pass c to update classvariable until null to return''' 
        max = Math.max(max, depth);
    }
  
}
